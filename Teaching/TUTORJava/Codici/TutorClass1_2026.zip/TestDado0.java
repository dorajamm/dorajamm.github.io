public class TestDado0
{
   public static void main(String args[])
   {
      Dado miodado = new Dado();

      int freq1 = 0, freq2 = 0, freq3 = 0;
      int freq4 = 0, freq5 = 0, freq6 = 0;

      int i;
      int ris;

      // risultati di 600000 lanci
      for (i = 1; i <= 600000; i++)
      {
         miodado.lancia();
         ris = miodado.faccia;

         switch (ris)
         {
            case 1:
               freq1++;
               break;
            case 2:
               freq2++;
               break;
            case 3:
               freq3++;
               break;
            case 4:
               freq4++;
               break;
            case 5:
               freq5++;
               break;
            case 6:
               freq6++;
               break;
         }
      }

      System.out.println("Risultato\tFrequenza");
      System.out.println("1\t\t" + freq1);
      System.out.println("2\t\t" + freq2);
      System.out.println("3\t\t" + freq3);
      System.out.println("4\t\t" + freq4);
      System.out.println("5\t\t" + freq5);
      System.out.println("6\t\t" + freq6);
   }
}
